from exmodule import deohagi as d

print(d(3, 4))
print(d(3, 4.5))
