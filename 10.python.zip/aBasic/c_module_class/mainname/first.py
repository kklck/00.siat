print('first 모듈 시작')
print('first.py __name__:', __name__)    # __name__ 변수 출력, 이 곳에서 실행하면 __main__ 출력, 다른 곳에서 가져와 실행하면 __파일이름__
print('first 모듈 끝')