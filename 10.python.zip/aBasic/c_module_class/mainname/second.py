import first  # first 모듈을 가져옴

print('second.py __name__:', __name__)  # __name__ 변수 출력, 이 곳에서 실행하면 __main__ 출력
