def deohagi(a, b):
    if type(a) != type(b):
        print("다른 자료형은 연산할 수 없습니다.")
        return ""
    else:
        return a + b
